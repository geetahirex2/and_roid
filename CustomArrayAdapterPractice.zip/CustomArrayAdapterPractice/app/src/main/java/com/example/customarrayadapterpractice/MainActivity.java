package com.example.customarrayadapterpractice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

class CustomBaseAdapter extends BaseAdapter{

    Context c;
    String[] cnames;
    int[] cflags;
    LayoutInflater inflater;

    public CustomBaseAdapter (Context c, String[] cnames, int[] cflags){
        this.c = c;
        this.cnames = cnames;
        this.cflags = cflags;
        inflater = LayoutInflater.from(c);
    }

    @Override
    public int getCount() {
        return cnames.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        convertView = inflater.inflate(R.layout.activity_customlistview, null);

        TextView text = convertView.findViewById(R.id.text);
        ImageView image = convertView.findViewById(R.id.image);

        text.setText(cnames[position]);
        image.setImageResource(cflags[position]);

        return convertView;
    }

}

public class MainActivity extends AppCompatActivity {

    String countrylist[] = {"America", "Australia", "China", "India", "New Zealand", "Portugal"};
    int flags[] = {R.drawable.america, R.drawable.australia, R.drawable.china, R.drawable.india, R.drawable.new_zealand, R.drawable.portugal};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView lv = findViewById(R.id.customlv);

        CustomBaseAdapter cba = new CustomBaseAdapter(getApplicationContext(), countrylist, flags);
        lv.setAdapter(cba);
    }
}

