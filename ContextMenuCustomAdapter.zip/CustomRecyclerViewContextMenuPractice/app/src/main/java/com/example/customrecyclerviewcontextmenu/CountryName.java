package com.example.customrecyclerviewcontextmenu;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.customrecyclerviewcontextmenupractice.R;

public class CountryName extends AppCompatActivity {

    TextView countryName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country_name);

        countryName = findViewById(R.id.country_name);

        Bundle extras = getIntent().getExtras();

        if (extras != null) {
            String value = extras.getString("countryName");
            countryName.setText(value);
        }
    }
}