package com.example.customrecyclerviewcontextmenu;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.customrecyclerviewcontextmenupractice.R;

public class CountryFlag extends AppCompatActivity {

    ImageView countryFlag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country_flag);

        countryFlag = findViewById(R.id.country_flag);

        Bundle extras = getIntent().getExtras();

        if (extras != null) {
            int value = extras.getInt("countryFlag");
            countryFlag.setImageResource(value);
        }
    }
}