package com.example.customrecyclerviewcontextmenu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.customrecyclerviewcontextmenupractice.R;

import java.util.ArrayList;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerViewHolder> {

    Context context;
    ArrayList<RecyclerModel> items;

    public RecyclerAdapter(Context context, ArrayList<RecyclerModel> items) {
        this.context = context;
        this.items = items;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.country_list_items_view, parent, false);
        return new RecyclerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position) {
        holder.countryName.setText(items.get(position).getCountryName());
        holder.countryCapital.setText(items.get(position).getCountryCapital());
        holder.countryFlag.setImageResource(items.get(position).getCountryFlag());

    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}
