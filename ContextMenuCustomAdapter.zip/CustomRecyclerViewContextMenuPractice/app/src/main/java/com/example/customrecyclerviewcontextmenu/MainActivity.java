package com.example.customrecyclerviewcontextmenu;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.customrecyclerviewcontextmenupractice.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;

    Intent intent;

    String countryNames[] = {
            "India", "USA", "Canada", "Nepal", "Bhutan", "China", "England", "Germany", "France", "Netherlands"
    };

    String countryCapitals[]= {
            "New Delhi", "Washington, D.C.", "Ottawa", "Kathmandu", "Thimphu", "Beijing", "London", "Berlin", "Paris", "Amsterdam"
    };

    int countryFlags[] = {
            R.drawable.india, R.drawable.usa, R.drawable.canada, R.drawable.nepal, R.drawable.bhutan, R.drawable.china, R.drawable.england, R.drawable.germany, R.drawable.france, R.drawable.netherland
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_view_example);

        ArrayList<RecyclerModel> items = new ArrayList<>();

        for (int i = 0; i < countryNames.length; i++) {
            items.add(new RecyclerModel(countryNames[i], countryCapitals[i],countryFlags[i]));
        }

        recyclerView = findViewById(R.id.myRecyclerView);

        RecyclerAdapter recyclerAdapter = new RecyclerAdapter(getApplicationContext(), items);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(recyclerAdapter);
    }

    // this code is for context menu
    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case 101:
                intent = new Intent(getApplicationContext(), CountryName.class);
                intent.putExtra("countryName", countryNames[item.getGroupId()]);
                startActivity(intent);
                return true;
            case 102:
                intent = new Intent(getApplicationContext(), Capital.class);
                intent.putExtra("countryCapital", countryCapitals[item.getGroupId()]);
                startActivity(intent);
                return true;
            case 103:
                intent = new Intent(getApplicationContext(), CountryFlag.class);
                intent.putExtra("countryFlag", countryFlags[item.getGroupId()]);
                startActivity(intent);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }
}