package com.example.customrecyclerviewcontextmenu;

public class RecyclerModel {

    String countryName, countryCapital;
    int countryFlag;

    public RecyclerModel(String countryName, String countryCapital, int countryFlag) {
        this.countryName = countryName;
        this.countryCapital = countryCapital;
        this.countryFlag = countryFlag;
    }

    public String getCountryName() {
        return countryName;
    }

    public String getCountryCapital() {
        return countryCapital;
    }

    public int getCountryFlag() {
        return countryFlag;
    }
}
