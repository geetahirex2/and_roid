package com.example.customrecyclerviewcontextmenu;

import android.view.ContextMenu;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.customrecyclerviewcontextmenupractice.R;

public class RecyclerViewHolder extends RecyclerView.ViewHolder implements View.OnCreateContextMenuListener {

    TextView countryName, countryCapital;
    ImageView countryFlag;

    CardView countryCard;

    public RecyclerViewHolder(@NonNull View itemView) {
        super(itemView);

        countryName = itemView.findViewById(R.id.countryName);
        countryCapital = itemView.findViewById(R.id.countryCapital);
        countryFlag = itemView.findViewById(R.id.countryFlag);
        countryCard = itemView.findViewById(R.id.countryCard);

        // here we are setting listening item that triggers menu
        countryCard.setOnCreateContextMenuListener(this);
    }

    // here we are setting options items for context menu
    @Override
    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        contextMenu.add(getAdapterPosition(), 101, 0, "Country Name");
        contextMenu.add(getAdapterPosition(), 102, 1, "Capital");
        contextMenu.add(getAdapterPosition(), 103, 2, "Flag");
    }
}
