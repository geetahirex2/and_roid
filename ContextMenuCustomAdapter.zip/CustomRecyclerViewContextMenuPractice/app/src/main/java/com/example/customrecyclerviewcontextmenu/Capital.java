package com.example.customrecyclerviewcontextmenu;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.customrecyclerviewcontextmenupractice.R;

public class Capital extends AppCompatActivity {

    TextView capital;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_capital);

        capital = findViewById(R.id.country_capital);

        Bundle extras = getIntent().getExtras();

        if (extras != null) {
            String value = extras.getString("countryCapital");
            capital.setText(value);
        }
    }
}