package com.example.autocomplete;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

    public class MainActivity extends AppCompatActivity {

        AutoCompleteTextView autoCompleteTextView;

        String students[] = {"Alice", "Amanda", "Bob", "Bhaudya", "Charlie", "Chintu", "David", "Dravid", "Emily", "Ella", "Frank", "Fernandez", "Grace", "Geet", "Henry", "Harsh", "Isabella", "India", "Jacob", "Jhandu", "Kate", "Liam", "Mia", "Nathan", "Olivia", "Ocean", "Peter", "Quinn", "Rachel", "Samantha", "Sanika", "Thomas"};

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            autoCompleteTextView = findViewById(R.id.autoTextView);

            ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, students);

            autoCompleteTextView.setAdapter(adapter);
        }
    }