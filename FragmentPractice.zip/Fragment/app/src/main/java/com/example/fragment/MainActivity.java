package com.example.fragment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btn1, btn2, btn3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1 = findViewById(R.id.MainB1);
        btn2 = findViewById(R.id.MainB2);



        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String a="";
                fragmentLoad(new AFragment(a),0);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fragmentLoad(new BFragment(), 1);
            }
        });

    }

    @SuppressLint("SuspiciousIndentation")
    public void fragmentLoad(Fragment fragment, int flag){
        FragmentManager  fragmentManager= getSupportFragmentManager();
        FragmentTransaction fragmentTransaction= fragmentManager.beginTransaction();
        if(flag==0)
            fragmentTransaction.add(R.id.Container, fragment);
        else if(flag==1)
            fragmentTransaction.replace(R.id.Container, fragment);
        fragmentTransaction.commit();
    }

}