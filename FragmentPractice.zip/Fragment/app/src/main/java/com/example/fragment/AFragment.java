package com.example.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;

public class AFragment extends Fragment {

    ListView listView;
    ArrayList<String> arrayList;
    ArrayAdapter<String> arrayAdapter;
    String[] students= {"anant","paresh","sukanya","dhanashree","Uday","Kakshil","atharv","sahil","suyash","pranay","anant","paresh","sukanya","dhanashree","Uday","Kakshil","atharv","sahil","suyash","pranay"};
    String newStudent;
    public AFragment(String newStudnet) {
        this.newStudent=newStudnet;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_a, container, false);
        listView= view.findViewById(R.id.Frag_A_List);
        arrayList = new ArrayList<String>(Arrays.asList(students));
        arrayAdapter= new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1,arrayList);
        listView.setAdapter(arrayAdapter);
        arrayList.add(newStudent);
        return view;
    }
}