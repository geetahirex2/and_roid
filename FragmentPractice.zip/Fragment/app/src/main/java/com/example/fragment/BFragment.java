package com.example.fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class BFragment extends Fragment {
    EditText editText;
    Button button;
    public BFragment() {
        // Required empty public constructor
    }
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_b, container, false);
        button= view.findViewById(R.id.AddStudent);
        editText= view.findViewById(R.id.StudentEditText);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               String newStudent= editText.getText().toString();
                if (newStudent.equals("")){
                    Toast.makeText(getActivity(), "Please fill the field", Toast.LENGTH_SHORT).show();
                }else{
                    getActivity().getSupportFragmentManager().beginTransaction()
                            .replace(R.id.Container,new AFragment(newStudent)).commit();
                }
            }
        });

        return view;
    }
}