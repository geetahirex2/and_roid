package com.example.customsimplearrayadapterpractice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.Inflater;

class CustomSimpleAdapter extends SimpleAdapter {

    Context c;
    String[] names;
    int[] images;
    LayoutInflater inflater;
    ArrayList<HashMap<String,String>> arrayList;

    public CustomSimpleAdapter(Context context, ArrayList<HashMap<String, String>> data, int resource, String[] from, int[] to) {
        super(context, data, resource, from, to);

        this.c = context;
        this.arrayList = data;
        inflater.from(context);
    }
    
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View view = super.getView(position, convertView, parent);
        ImageView imageView = (ImageView) view.findViewById(R.id.image);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(c, arrayList.get(position).get("Name"), Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }
}

public class MainActivity extends AppCompatActivity {

    String[] names = {"geet", "sanika", "geet", "sanika", "geet"};
    int[] images = {R.drawable.lion3, R.drawable.tiger3, R.drawable.tiger2, R.drawable.tiger1, R.drawable.cat2};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView simpleListView = (ListView) findViewById (R.id.lv);

        ArrayList<HashMap<String, String>> arrayList = new ArrayList<HashMap<String, String>>();

        for (int i = 0; i < names.length; i++){
            HashMap<String, String> hm = new HashMap<>();
            hm.put("Name", names[i]);
            hm.put("Image", images[i] + "");
            arrayList.add(hm);
        }

        String[] from = {"Name", "Image"};
        int[] to = {R.id.text, R.id.image};

        CustomSimpleAdapter simpleAdapter = new CustomSimpleAdapter(this, arrayList, R.layout.list_item, from, to);
        simpleListView.setAdapter(simpleAdapter);

        simpleListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(MainActivity.this, names[position], Toast.LENGTH_SHORT).show();
            }
        });

    }
}