package com.example.customsimpleadaptergridview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    String teacherNames[] = {"Goje", "Khande", "Devyani", "Navnath", "Sagar"};
    String designation[] = {"Professor", "Associate head", "Assistant professor", "Professor", "Visiting Professor"};

    GridView gridView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<HashMap<String, String>> arrayList = new ArrayList<>();

        gridView = findViewById(R.id.gridView);

        for (int i = 0; i < teacherNames.length; i++) {
            HashMap<String, String> hashMap = new HashMap<>();

            hashMap.put("teacherName", teacherNames[i]);
            hashMap.put("designation", designation[i]);

            arrayList.add(hashMap);
        }

        String from[] = {"teacherName", "designation"};
        int to[] = {R.id.teacherName, R.id.teacherDesignation};

        SimpleAdapter simpleAdapter = new SimpleAdapter(getApplicationContext(), arrayList, R.layout.custom_grid_layout, from, to);

        gridView.setAdapter(simpleAdapter);

        registerForContextMenu(gridView);
    }
}