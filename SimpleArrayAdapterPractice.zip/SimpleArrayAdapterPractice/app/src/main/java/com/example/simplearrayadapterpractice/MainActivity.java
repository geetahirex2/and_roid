package com.example.simplearrayadapterpractice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    String[] names = {"geet", "sanika", "geet", "sanika", "geet"};
    int[] images = {R.drawable.lion3, R.drawable.tiger3, R.drawable.tiger2, R.drawable.tiger1, R.drawable.cat2};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView simpleListView = (ListView) findViewById (R.id.lv);

        ArrayList<HashMap<String, String>> arrayList = new ArrayList<HashMap<String, String>>();

        for (int i = 0; i < names.length; i++){
            HashMap<String, String> hm = new HashMap<>();
            hm.put("Name", names[i]);
            hm.put("Image", images[i] + "");
            arrayList.add(hm);
        }

        String[] from = {"Name", "Image"};
        int[] to = {R.id.text, R.id.image};

        SimpleAdapter simpleAdapter = new SimpleAdapter(this, arrayList, R.layout.list_item, from, to);
        simpleListView.setAdapter(simpleAdapter);

        simpleListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(MainActivity.this, names[position], Toast.LENGTH_SHORT).show();
            }
        });

    }
}